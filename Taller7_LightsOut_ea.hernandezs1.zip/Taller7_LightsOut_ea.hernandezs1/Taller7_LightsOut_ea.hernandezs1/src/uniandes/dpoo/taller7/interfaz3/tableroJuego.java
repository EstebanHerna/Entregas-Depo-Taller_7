package uniandes.dpoo.taller7.interfaz3;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.*;

public class tableroJuego extends JPanel implements MouseListener {
    private static final long serialVersionUID = 1L;
    private int ladoTablero = 5;

    public tableroJuego() {
        addMouseListener(this);
    }

    public void paint(Graphics g) {

        boolean[][] tableroJuego = mainInterface.tablero.darTablero();
        ladoTablero = mainInterface.tamano;

        int ancho = getWidth() / ladoTablero - 1;
        int alto = getHeight() / ladoTablero - 1;

        for (int i = 0; i < ladoTablero; i++) {
            for (int j = 0; j < ladoTablero; j++) {
                if (tableroJuego[i][j] == true) {
                    g.setColor(Color.YELLOW);
                    g.fillRect(i * ancho, j * alto, ancho, alto);
                    g.setColor(Color.BLACK);
                    g.drawRect(i * ancho, j * alto, ancho, alto);

                } else {
                    g.setColor(Color.GRAY);
                    g.fillRect(i * ancho, j * alto, ancho, alto);
                    g.setColor(Color.BLACK);
                    g.drawRect(i * ancho, j * alto, ancho, alto);
                }

            }

        }
    }

    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseClicked(MouseEvent e) {
        // TODO Auto-generated method stub
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        // TODO Auto-generated method stub
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        // TODO Auto-generated method stub
    }

    @Override
    public void mouseExited(MouseEvent e) {
        // TODO Auto-generated method stub
    }
}
