package uniandes.dpoo.taller7.interfaz3;

import javax.swing.*;

import java.awt.*;

public class rightSide extends JPanel {
    private static final long serialVersionUID = 1L;

    private JButton buttonNuevo;
    private JButton buttonReiniciar;
    private JButton buttonTopTen;
    private JButton buttonCambiarJugador;

    public rightSide(int width) {
        setLayout(new GridLayout(9, 1));
        setPreferredSize(new Dimension((int) (width * 0.27), 480));
        setBackground(Color.white);
        add(new JLabel(""));
        buttonNuevo = new JButton();
        buttonNuevo.setText("Nuevo");
        buttonNuevo.setFocusable(false);
        buttonNuevo.setBackground(new Color(102, 178, 255));
        buttonNuevo.setForeground(Color.BLACK);

        add(buttonNuevo);

        add(new JLabel(""));

        buttonReiniciar = new JButton();
        buttonReiniciar.setText("Reiniciar");
        buttonReiniciar.setFocusable(false);
        buttonReiniciar.setEnabled(false);
        buttonReiniciar.setBackground(new Color(102, 178, 255));
        buttonReiniciar.setForeground(Color.BLACK);

        add(buttonReiniciar);
        add(new JLabel(""));
        buttonTopTen = new JButton();
        buttonTopTen.setText("Top - 10");
        buttonTopTen.setFocusable(false);
        buttonTopTen.setBackground(new Color(102, 178, 255));
        buttonTopTen.setForeground(Color.BLACK);

        add(buttonTopTen);
        add(new JLabel(""));

        buttonCambiarJugador = new JButton();
        buttonCambiarJugador.setText("Cambiar Jugador");
        buttonCambiarJugador.setFocusable(false);
        buttonCambiarJugador.setBackground(new Color(102, 178, 255));
        buttonCambiarJugador.setForeground(Color.BLACK);

        add(buttonCambiarJugador);
        add(new JLabel(""));

    }
}
