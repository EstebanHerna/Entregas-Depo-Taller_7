package uniandes.dpoo.taller7.interfaz2;

import java.awt.*;

import javax.swing.*;

public class arriba extends JPanel {
    private static final long serialVersionUID = 1L;
    private JComboBox<String> sizeComboBox;
    private JRadioButton easyRadioButton;
    private JRadioButton mediumRadioButton;
    private JRadioButton hardRadioButton;

    public arriba() {
        this.setLayout(new GridLayout(1, 7));
        setPreferredSize(new Dimension(getWidth(), 60));

        JLabel sizeLabel = new JLabel("Tamano:");
        sizeLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        sizeLabel.setHorizontalAlignment(SwingConstants.CENTER);

        this.add(sizeLabel);

        String[] sizes = { "5x5", "7x7", "9x9" };
        sizeComboBox = new JComboBox<>(sizes);
        sizeComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        this.add(sizeComboBox);

        JLabel difficultyLabel = new JLabel("Dificultad:");
        difficultyLabel.setHorizontalAlignment(SwingConstants.CENTER);
        difficultyLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        this.add(difficultyLabel);

        ButtonGroup difficultyGroup = new ButtonGroup();

        easyRadioButton = new JRadioButton("Facil");
        easyRadioButton.setSelected(true);
        easyRadioButton.setFont(new Font("Arial", Font.PLAIN, 14));
        difficultyGroup.add(easyRadioButton);
        this.add(easyRadioButton);

        mediumRadioButton = new JRadioButton("Medio");
        mediumRadioButton.setFont(new Font("Arial", Font.PLAIN, 14));
        difficultyGroup.add(mediumRadioButton);
        this.add(mediumRadioButton);

        hardRadioButton = new JRadioButton("Dificil");
        hardRadioButton.setFont(new Font("Arial", Font.PLAIN, 14));
        difficultyGroup.add(hardRadioButton);
        this.add(hardRadioButton);
    }

}
