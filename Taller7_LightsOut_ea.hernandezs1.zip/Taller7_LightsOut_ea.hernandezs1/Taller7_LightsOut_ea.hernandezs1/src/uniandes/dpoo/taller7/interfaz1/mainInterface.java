package uniandes.dpoo.taller7.interfaz1;

import javax.swing.*;

import java.awt.*;

public class mainInterface extends JFrame {
    private static final long serialVersionUID = 1L;

    public mainInterface() {

        setTitle("Lights Out Game");
        setSize(600, 600);
        setResizable(false);
        setLocationRelativeTo(null);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        // Acá sirve el dispose on close,
        // sirve para guardar los cambos

        setLayout(new BorderLayout());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                mainInterface ventana = new mainInterface();
                ventana.setVisible(true);
            }
        });
    }
}